package com.mangomusic.dao;

import com.mangomusic.model.User;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class UserDao {

    private final DataSource dataSource;

    public UserDao(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT user_id, username, email, signup_date, subscription_type, country " +
                "FROM users " +
                "ORDER BY username";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet results = statement.executeQuery()) {

            while (results.next()) {
                User user = mapRowToUser(results);
                users.add(user);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting all users", e);
        }

        return users;
    }

    public User getUserById(int userId) {
        String query = "SELECT user_id, username, email, signup_date, subscription_type, country " +
                "FROM users " +
                "WHERE user_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, userId);

            try (ResultSet results = statement.executeQuery()) {
                if (results.next()) {
                    return mapRowToUser(results);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting user by id: " + userId, e);
        }

        return null;
    }

    public List<User> searchUsers(String searchTerm) {
        List<User> users = new ArrayList<>();
        String query = "SELECT user_id, username, email, signup_date, subscription_type, country " +
                "FROM users " +
                "WHERE username LIKE ? OR email LIKE ? " +
                "ORDER BY username";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + searchTerm + "%");
            statement.setString(2, "%" + searchTerm + "%");

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    User user = mapRowToUser(results);
                    users.add(user);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error searching for users", e);
        }

        return users;
    }

    public List<User> getUsersByCountry(String country) {
        List<User> users = new ArrayList<>();
        String query = "SELECT user_id, username, email, signup_date, subscription_type, country " +
                "FROM users " +
                "WHERE country = ? " +
                "ORDER BY username";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, country);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    User user = mapRowToUser(results);
                    users.add(user);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting users by country", e);
        }

        return users;
    }

    public List<User> getUsersBySubscriptionType(String subscriptionType) {
        List<User> users = new ArrayList<>();
        String query = "SELECT user_id, username, email, signup_date, subscription_type, country " +
                "FROM users " +
                "WHERE subscription_type = ? " +
                "ORDER BY username";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, subscriptionType);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    User user = mapRowToUser(results);
                    users.add(user);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting users by subscription type", e);
        }

        return users;
    }

    public User createUser(User user) {
        String query = "INSERT INTO users (username, email, signup_date, subscription_type, country) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, user.getUsername());
            statement.setString(2, user.getEmail());
            statement.setDate(3, Date.valueOf(user.getSignupDate()));
            statement.setString(4, user.getSubscriptionType());
            statement.setString(5, user.getCountry());

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating user failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1));
                    return user;
                } else {
                    throw new SQLException("Creating user failed, no ID obtained.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error creating user", e);
        }
    }

    public User updateUser(int userId, User user) {
        String query = "UPDATE users SET username = ?, email = ?, signup_date = ?, " +
                "subscription_type = ?, country = ? WHERE user_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, user.getUsername());
            statement.setString(2, user.getEmail());
            statement.setDate(3, Date.valueOf(user.getSignupDate()));
            statement.setString(4, user.getSubscriptionType());
            statement.setString(5, user.getCountry());
            statement.setInt(6, userId);

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                return null;
            }

            user.setUserId(userId);
            return user;

        } catch (SQLException e) {
            throw new RuntimeException("Error updating user", e);
        }
    }

    public boolean deleteUser(int userId) {
        String query = "DELETE FROM users WHERE user_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, userId);
            int affectedRows = statement.executeUpdate();

            return affectedRows > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error deleting user", e);
        }
    }

    public Map<String, Object> getFavoriteGenre(int userId) {
        String query = "SELECT u.user_id, u.username, ar.primary_genre, COUNT(ap.play_id) as plays_in_genre " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "JOIN users u ON ap.user_id = u.user_id " +
                "WHERE ap.user_id = ? " +
                "GROUP BY u.user_id, u.username, ar.primary_genre " +
                "ORDER BY plays_in_genre DESC, ar.primary_genre ASC " +
                "LIMIT 1";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, userId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    Map<String, Object> result = new HashMap<>();
                    result.put("userId", rs.getInt("user_id"));
                    result.put("username", rs.getString("username"));
                    result.put("favoriteGenre", rs.getString("primary_genre"));
                    result.put("playsInGenre", rs.getInt("plays_in_genre"));
                    return result;
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting favorite genre", e);
        }

        return null;
    }

    private User mapRowToUser(ResultSet rs) throws SQLException {
        int userId = rs.getInt("user_id");
        String username = rs.getString("username");
        String email = rs.getString("email");
        LocalDate signupDate = rs.getDate("signup_date").toLocalDate();
        String subscriptionType = rs.getString("subscription_type");
        String country = rs.getString("country");

        return new User(userId, username, email, signupDate, subscriptionType, country);
    }
}
package com.mangomusic.dao;

import com.mangomusic.model.Artist;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ArtistDao {

    private final DataSource dataSource;

    public ArtistDao(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public List<Artist> getAllArtists() {
        List<Artist> artists = new ArrayList<>();
        String query = "SELECT artist_id, name, primary_genre, formed_year FROM artists ORDER BY name";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet results = statement.executeQuery()) {

            while (results.next()) {
                Artist artist = mapRowToArtist(results);
                artists.add(artist);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting all artists", e);
        }

        return artists;
    }

    public Artist getArtistById(int artistId) {
        String query = "SELECT artist_id, name, primary_genre, formed_year FROM artists WHERE artist_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, artistId);

            try (ResultSet results = statement.executeQuery()) {
                if (results.next()) {
                    return mapRowToArtist(results);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting artist by id: " + artistId, e);
        }

        return null;
    }

    public List<Artist> searchArtists(String searchTerm) {
        List<Artist> artists = new ArrayList<>();
        String query = "SELECT artist_id, name, primary_genre, formed_year " +
                "FROM artists " +
                "WHERE name LIKE ? " +
                "ORDER BY name";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + searchTerm + "%");

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    Artist artist = mapRowToArtist(results);
                    artists.add(artist);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error searching for artists", e);
        }

        return artists;
    }

    public Artist createArtist(Artist artist) {
        String query = "INSERT INTO artists (name, primary_genre, formed_year) VALUES (?, ?, ?)";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, artist.getName());
            statement.setString(2, artist.getPrimaryGenre());
            statement.setObject(3, artist.getFormedYear());

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating artist failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    artist.setArtistId(generatedKeys.getInt(1));
                    return artist;
                } else {
                    throw new SQLException("Creating artist failed, no ID obtained.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error creating artist", e);
        }
    }

    public Artist updateArtist(int artistId, Artist artist) {
        String query = "UPDATE artists SET name = ?, primary_genre = ?, formed_year = ? WHERE artist_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, artist.getName());
            statement.setString(2, artist.getPrimaryGenre());
            statement.setObject(3, artist.getFormedYear());
            statement.setInt(4, artistId);

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                return null;
            }

            artist.setArtistId(artistId);
            return artist;

        } catch (SQLException e) {
            throw new RuntimeException("Error updating artist", e);
        }
    }

    public boolean deleteArtist(int artistId) {
        String query = "DELETE FROM artists WHERE artist_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, artistId);
            int affectedRows = statement.executeUpdate();

            return affectedRows > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error deleting artist", e);
        }
    }

    public List<String> getAllGenres() {
        List<String> genres = new ArrayList<>();
        String query = "SELECT DISTINCT primary_genre FROM artists ORDER BY primary_genre";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet results = statement.executeQuery()) {

            while (results.next()) {
                genres.add(results.getString("primary_genre"));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting genres", e);
        }

        return genres;
    }

    private Artist mapRowToArtist(ResultSet rs) throws SQLException {
        int artistId = rs.getInt("artist_id");
        String name = rs.getString("name");
        String genre = rs.getString("primary_genre");
        Integer formedYear = rs.getObject("formed_year", Integer.class);

        return new Artist(artistId, name, genre, formedYear);
    }
}
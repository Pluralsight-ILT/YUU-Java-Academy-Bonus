package com.mangomusic.service;

import com.mangomusic.dao.ArtistDao;
import com.mangomusic.dao.AlbumDao;
import com.mangomusic.model.Artist;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ArtistService {

    private final ArtistDao artistDao;
    private final AlbumDao albumDao;

    public ArtistService(ArtistDao artistDao, AlbumDao albumDao) {
        this.artistDao = artistDao;
        this.albumDao = albumDao;
    }

    public List<Artist> getAllArtists() {
        return artistDao.getAllArtists();
    }

    public Artist getArtistById(int artistId) {
        return artistDao.getArtistById(artistId);
    }

    public List<Artist> searchArtists(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllArtists();
        }
        return artistDao.searchArtists(searchTerm);
    }

    public Artist createArtist(Artist artist) {
        validateArtist(artist);
        return artistDao.createArtist(artist);
    }

    public Artist updateArtist(int artistId, Artist artist) {
        validateArtist(artist);

        Artist existing = artistDao.getArtistById(artistId);
        if (existing == null) {
            return null;
        }

        return artistDao.updateArtist(artistId, artist);
    }

    public boolean deleteArtist(int artistId) {
        Artist existing = artistDao.getArtistById(artistId);
        if (existing == null) {
            return false;
        }

        return artistDao.deleteArtist(artistId);
    }

    public Map<String, Object> getTopAlbumForArtist(int artistId) {
        Artist artist = artistDao.getArtistById(artistId);
        if (artist == null) {
            return null;
        }

        return albumDao.getTopAlbumForArtist(artistId);
    }

    public List<String> getAllGenres() {
        return artistDao.getAllGenres();
    }

    private void validateArtist(Artist artist) {
        if (artist.getName() == null || artist.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Artist name is required");
        }
        if (artist.getPrimaryGenre() == null || artist.getPrimaryGenre().trim().isEmpty()) {
            throw new IllegalArgumentException("Primary genre is required");
        }
    }
}
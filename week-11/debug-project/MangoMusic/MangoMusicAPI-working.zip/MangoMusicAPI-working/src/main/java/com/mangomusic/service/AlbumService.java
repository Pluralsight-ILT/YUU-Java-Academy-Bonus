package com.mangomusic.service;

import com.mangomusic.dao.AlbumDao;
import com.mangomusic.dao.ArtistDao;
import com.mangomusic.model.Album;
import com.mangomusic.model.Artist;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AlbumService {

    private final AlbumDao albumDao;
    private final ArtistDao artistDao;

    public AlbumService(AlbumDao albumDao, ArtistDao artistDao) {
        this.albumDao = albumDao;
        this.artistDao = artistDao;
    }

    public List<Album> getAllAlbums() {
        return albumDao.getAllAlbums();
    }

    public Album getAlbumById(int albumId) {
        return albumDao.getAlbumById(albumId);
    }

    public List<Album> getAlbumsByArtist(int artistId) {
        return albumDao.getAlbumsByArtist(artistId);
    }

    public List<Album> getAlbumsByGenre(String genre) {
        return albumDao.getAlbumsByGenre(genre);
    }

    public List<Album> searchAlbums(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllAlbums();
        }
        return albumDao.searchAlbums(searchTerm);
    }

    public Album createAlbum(Album album) {
        validateAlbum(album);

        Artist artist = artistDao.getArtistById(album.getArtistId());
        if (artist == null) {
            throw new IllegalArgumentException("Artist not found with id: " + album.getArtistId());
        }

        Album created = albumDao.createAlbum(album);
        created.setArtistName(artist.getName());
        return created;
    }

    public Album updateAlbum(int albumId, Album album) {
        validateAlbum(album);

        Album existing = albumDao.getAlbumById(albumId);
        if (existing == null) {
            return null;
        }

        Artist artist = artistDao.getArtistById(album.getArtistId());
        if (artist == null) {
            throw new IllegalArgumentException("Artist not found with id: " + album.getArtistId());
        }

        Album updated = albumDao.updateAlbum(albumId, album);
        if (updated != null) {
            updated.setArtistName(artist.getName());
        }
        return updated;
    }

    public Map<String, Object> getAlbumPlayCount(int albumId) {
        Album album = albumDao.getAlbumById(albumId);
        if (album == null) {
            return null;
        }

        int playCount = albumDao.getAlbumPlayCount(albumId);

        Map<String, Object> result = new HashMap<>();
        result.put("albumId", album.getAlbumId());
        result.put("albumTitle", album.getTitle());
        result.put("artistName", album.getArtistName());
        result.put("playCount", playCount);

        return result;
    }

    public List<Album> getRecentAlbums(int limit) {
        if (limit > 100) {
            limit = 100;
        }
        if (limit < 1) {
            limit = 10;
        }
        return albumDao.getRecentAlbums(limit);
    }

    public List<Map<String, Object>> getTrendingAlbums(int days) {
        if (days > 30) {
            days = 30;
        }
        if (days < 1) {
            days = 1;
        }
        return albumDao.getTrendingAlbums(days);
    }

    public boolean deleteAlbum(int albumId) {
        Album existing = albumDao.getAlbumById(albumId);
        if (existing == null) {
            return false;
        }

        return albumDao.deleteAlbum(albumId);
    }

    private void validateAlbum(Album album) {
        if (album.getTitle() == null || album.getTitle().trim().isEmpty()) {
            throw new IllegalArgumentException("Album title is required");
        }
        if (album.getArtistId() <= 0) {
            throw new IllegalArgumentException("Valid artist ID is required");
        }
        if (album.getReleaseYear() < 1900 || album.getReleaseYear() > 2100) {
            throw new IllegalArgumentException("Release year must be between 1900 and 2100");
        }
    }
}
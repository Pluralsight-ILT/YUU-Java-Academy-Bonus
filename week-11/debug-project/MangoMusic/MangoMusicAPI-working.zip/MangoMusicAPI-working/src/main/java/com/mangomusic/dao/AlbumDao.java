package com.mangomusic.dao;

import com.mangomusic.model.Album;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class AlbumDao {

    private final DataSource dataSource;

    public AlbumDao(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public List<Album> getAllAlbums() {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "ORDER BY al.title";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet results = statement.executeQuery()) {

            while (results.next()) {
                Album album = mapRowToAlbum(results);
                albums.add(album);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting all albums", e);
        }

        return albums;
    }

    public Album getAlbumById(int albumId) {
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE al.album_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, albumId);

            try (ResultSet results = statement.executeQuery()) {
                if (results.next()) {
                    return mapRowToAlbum(results);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting album by id: " + albumId, e);
        }

        return null;
    }

    public List<Album> getAlbumsByArtist(int artistId) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE al.artist_id = ? " +
                "ORDER BY al.release_year DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, artistId);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    Album album = mapRowToAlbum(results);
                    albums.add(album);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting albums for artist", e);
        }

        return albums;
    }

    public List<Album> getAlbumsByGenre(String genre) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE ar.primary_genre = ? " +
                "ORDER BY al.title";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, genre);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    Album album = mapRowToAlbum(results);
                    albums.add(album);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting albums by genre", e);
        }

        return albums;
    }

    public List<Album> searchAlbums(String searchTerm) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE al.title LIKE ? " +
                "ORDER BY al.title";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + searchTerm + "%");

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    Album album = mapRowToAlbum(results);
                    albums.add(album);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error searching for albums", e);
        }

        return albums;
    }

    public Album createAlbum(Album album) {
        String query = "INSERT INTO albums (artist_id, title, release_year) VALUES (?, ?, ?)";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            statement.setInt(1, album.getArtistId());
            statement.setString(2, album.getTitle());
            statement.setInt(3, album.getReleaseYear());

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating album failed, no rows affected.");
            }

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    album.setAlbumId(generatedKeys.getInt(1));
                    return album;
                } else {
                    throw new SQLException("Creating album failed, no ID obtained.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error creating album", e);
        }
    }

    public Album updateAlbum(int albumId, Album album) {
        String query = "UPDATE albums SET artist_id = ?, title = ?, release_year = ? WHERE album_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, album.getArtistId());
            statement.setString(2, album.getTitle());
            statement.setInt(3, album.getReleaseYear());
            statement.setInt(4, albumId);

            int affectedRows = statement.executeUpdate();

            if (affectedRows == 0) {
                return null;
            }

            album.setAlbumId(albumId);
            return album;

        } catch (SQLException e) {
            throw new RuntimeException("Error updating album", e);
        }
    }

    public int getAlbumPlayCount(int albumId) {
        String query = "SELECT COUNT(*) as play_count FROM album_plays WHERE album_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, albumId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("play_count");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting album play count", e);
        }

        return 0;
    }

    public Map<String, Object> getTopAlbumForArtist(int artistId) {
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, " +
                "       ar.name as artist_name, COUNT(ap.play_id) as play_count " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "LEFT JOIN album_plays ap ON al.album_id = ap.album_id " +
                "WHERE al.artist_id = ? " +
                "GROUP BY al.album_id, al.artist_id, al.title, al.release_year, ar.name " +
                "ORDER BY play_count DESC, al.album_id ASC " +
                "LIMIT 1";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, artistId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    Map<String, Object> result = new HashMap<>();
                    result.put("albumId", rs.getInt("album_id"));
                    result.put("artistId", rs.getInt("artist_id"));
                    result.put("title", rs.getString("title"));
                    result.put("releaseYear", rs.getInt("release_year"));
                    result.put("artistName", rs.getString("artist_name"));
                    result.put("playCount", rs.getInt("play_count"));
                    return result;
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting top album for artist", e);
        }

        return null;
    }

    public List<Album> getRecentAlbums(int limit) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE al.release_year >= (YEAR(CURDATE()) - 2) " +
                "ORDER BY al.release_year DESC, al.title ASC " +
                "LIMIT ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, limit);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    Album album = mapRowToAlbum(results);
                    albums.add(album);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting recent albums", e);
        }

        return albums;
    }

    public List<Map<String, Object>> getTrendingAlbums(int days) {
        List<Map<String, Object>> trending = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, " +
                "       ar.name as artist_name, COUNT(ap.play_id) as recent_play_count " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE ap.played_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY) " +
                "GROUP BY al.album_id, al.artist_id, al.title, al.release_year, ar.name " +
                "ORDER BY recent_play_count DESC " +
                "LIMIT 10";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, days);

            try (ResultSet rs = statement.executeQuery()) {
                int rank = 1;
                while (rs.next()) {
                    Map<String, Object> album = new HashMap<>();
                    album.put("albumId", rs.getInt("album_id"));
                    album.put("artistId", rs.getInt("artist_id"));
                    album.put("title", rs.getString("title"));
                    album.put("releaseYear", rs.getInt("release_year"));
                    album.put("artistName", rs.getString("artist_name"));
                    album.put("recentPlayCount", rs.getInt("recent_play_count"));
                    album.put("trendingRank", rank++);
                    trending.add(album);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error getting trending albums", e);
        }

        return trending;
    }

    public boolean deleteAlbum(int albumId) {
        String query = "DELETE FROM albums WHERE album_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, albumId);
            int affectedRows = statement.executeUpdate();

            return affectedRows > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error deleting album", e);
        }
    }

    private Album mapRowToAlbum(ResultSet rs) throws SQLException {
        int albumId = rs.getInt("album_id");
        int artistId = rs.getInt("artist_id");
        String title = rs.getString("title");
        int releaseYear = rs.getInt("release_year");
        String artistName = rs.getString("artist_name");

        return new Album(albumId, artistId, title, releaseYear, artistName);
    }
}
package com.mangomusic.ui;

import com.mangomusic.dao.MangoMusicDataManager;
import com.mangomusic.util.ConsoleColors;
import com.mangomusic.util.InputValidator;

/**
 * Screen for special reports that students need to build from scratch
 * These are new features not from Week 1
 */
public class SpecialReportsScreen {

    private final MangoMusicDataManager dataManager;

    public SpecialReportsScreen(MangoMusicDataManager dataManager) {
        this.dataManager = dataManager;
    }

    /**
     * Displays the special reports menu
     */
    public void display() {
        boolean running = true;

        while (running) {
            InputValidator.clearScreen();
            displayMenu();

            int choice = InputValidator.getIntInRange("Select an option: ", 0, 3);

            switch (choice) {
                case 1:
                    showMostPlayedAlbumsByGenre();
                    break;
                case 2:
                    showUserDiversityScore();
                    break;
                case 3:
                    showPeakListeningHours();
                    break;
                case 0:
                    running = false;
                    break;
            }
        }
    }

    /**
     * Displays the special reports menu options
     */
    private void displayMenu() {
        ConsoleColors.printHeader("SPECIAL REPORTS");

        System.out.println("\nBUILD THESE REPORTS:");
        System.out.println("1. Most Played Albums by Genre");
        System.out.println("2. User Listening Diversity Score");
        System.out.println("3. Peak Listening Hours Analysis");

        System.out.println("\n0. Back to main menu");
        System.out.println();
    }

    /**
     * Feature 1: Most Played Albums by Genre
     * TODO: Students need to implement this
     */
    private void showMostPlayedAlbumsByGenre() {
        InputValidator.clearScreen();
        ConsoleColors.printSection("Most Played Albums by Genre");
        System.out.println("Shows top 5 albums per genre by play count\n");

        ConsoleColors.printError("This report has not been implemented yet.");
        System.out.println("\nYour task: Implement this feature in MangoMusicDataManager");
        System.out.println("See feature_tickets.md for requirements");

        InputValidator.pressEnterToContinue();
    }

    /**
     * Feature 2: User Listening Diversity Score
     * TODO: Students need to implement this
     */
    private void showUserDiversityScore() {
        InputValidator.clearScreen();
        ConsoleColors.printSection("User Listening Diversity Score");
        System.out.println("Shows users who explore different genres\n");

        ConsoleColors.printError("This report has not been implemented yet.");
        System.out.println("\nYour task: Implement this feature in MangoMusicDataManager");
        System.out.println("See feature_tickets.md for requirements");

        InputValidator.pressEnterToContinue();
    }

    /**
     * Feature 3: Peak Listening Hours Analysis
     * TODO: Students need to implement this
     */
    private void showPeakListeningHours() {
        InputValidator.clearScreen();
        ConsoleColors.printSection("Peak Listening Hours Analysis");
        System.out.println("Shows what time of day users are most active\n");

        ConsoleColors.printError("This report has not been implemented yet.");
        System.out.println("\nYour task: Implement this feature in MangoMusicDataManager");
        System.out.println("See feature_tickets.md for requirements");

        InputValidator.pressEnterToContinue();
    }
}
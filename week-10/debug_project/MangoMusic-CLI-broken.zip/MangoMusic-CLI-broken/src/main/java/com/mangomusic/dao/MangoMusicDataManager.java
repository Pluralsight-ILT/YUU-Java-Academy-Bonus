package com.mangomusic.dao;

import com.mangomusic.config.DatabaseConfig;
import com.mangomusic.models.*;
import org.apache.commons.dbcp2.BasicDataSource;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for MangoMusic database
 * Handles all database queries and result mapping
 */
public class MangoMusicDataManager {

    private final BasicDataSource dataSource;

    public MangoMusicDataManager() {
        this.dataSource = DatabaseConfig.getDataSource();
    }

    /**
     * Searches for artists by name (partial match)
     * @param searchTerm The name to search for
     * @return List of matching artists
     *
     */
    public List<Artist> searchArtists(String searchTerm) {
        List<Artist> artists = new ArrayList<>();
        String query = "SELECT artist_id, name, primary_genre, formed_year " +
                "FROM artists " +
                "WHERE name LIKE ? " +
                "ORDER BY name";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + searchTerm + "%");

            ResultSet results = statement.executeQuery(); // NOT in try-with-resources!

            while (results.next()) {
                int artistId = results.getInt("artist_id");
                String name = results.getString("name");
                String genre = results.getString("primary_genre");
                Integer formedYear = results.getObject("formed_year", Integer.class);

                artists.add(new Artist(artistId, name, genre, formedYear));
            }

        } catch (SQLException e) {
            System.err.println("Error searching for artists: " + e.getMessage());
            e.printStackTrace();
        }

        return artists;
    }

    /**
     * Gets all albums for a specific artist
     * @param artistId The artist's ID
     * @return List of albums by that artist
     *
     */
    public List<Album> getAlbumsByArtist(int artistId) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE al.artist_id = ? " +
                "ORDER BY al.release_year DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, artistId);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    int albumId = results.getInt("album_id");
                    int artId = results.getInt("artist_id"); // This exists
                    String title = results.getString("title");
                    int releaseYear = results.getInt("release_year");
                    String artistName = results.getString("artist"); // WRONG! Should be "artist_name"

                    albums.add(new Album(albumId, artId, title, releaseYear, artistName));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error getting albums for artist: " + e.getMessage());
            e.printStackTrace();
        }

        return albums;
    }

    /**
     * Searches for a user by username (exact or partial match)
     * @param username The username to search for
     * @return List of matching users
     *
     */
    public List<User> searchUsers(String username) {
        List<User> users = new ArrayList<>();
        String query = "SELECT user_id, username, email, signup_date, subscription_type, country " +
                "FROM users " +
                "WHERE username LIKE ? OR email LIKE ? " +
                "ORDER BY username";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + username + "%");
            statement.setString(1, "%" + username + "%"); // WRONG! Should be index 2

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    int userId = results.getInt("user_id");
                    String user = results.getString("username");
                    String email = results.getString("email");
                    LocalDate signupDate = results.getDate("signup_date").toLocalDate();
                    String subscriptionType = results.getString("subscription_type");
                    String country = results.getString("country");

                    users.add(new User(userId, user, email, signupDate, subscriptionType, country));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error searching for users: " + e.getMessage());
            e.printStackTrace();
        }

        return users;
    }

    /**
     * Gets recent album plays for a specific user
     * @param userId The user's ID
     * @param limit Maximum number of plays to return
     * @return List of recent plays
     *
     */
    public List<AlbumPlay> getUserRecentPlays(int userId, int limit) {
        List<AlbumPlay> plays = new ArrayList<>();
        String query = "SELECT ap.play_id, ap.user_id, ap.album_id, ap.played_at, ap.completed, " +
                "       al.title as album_title, ar.name as artist_name " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE ap.user_id = ? " +
                "ORDER BY ap.played_at DESC " +
                "LIMIT ?";

        try {
            Connection connection = dataSource.getConnection(); // NOT in try-with-resources!
            PreparedStatement statement = connection.prepareStatement(query);

            statement.setInt(1, userId);
            statement.setInt(2, limit);

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    long playId = results.getLong("play_id");
                    int uid = results.getInt("user_id");
                    int albumId = results.getInt("album_id");
                    LocalDateTime playedAt = results.getTimestamp("played_at").toLocalDateTime();
                    boolean completed = results.getBoolean("completed");
                    String albumTitle = results.getString("album_title");
                    String artistName = results.getString("artist_name");

                    plays.add(new AlbumPlay(playId, uid, albumId, playedAt, completed, albumTitle, artistName));
                }
            }

            statement.close();
            connection.close();

        } catch (SQLException e) {
            System.err.println("Error getting user plays: " + e.getMessage());
            e.printStackTrace();
        }

        return plays;
    }

    /**
     * Finds albums by genre
     * @param genre The genre to search for
     * @return List of albums in that genre
     *
     */
    public List<Album> getAlbumsByGenre(String genre) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE ar.primary_genre = '" + genre + "' " + // SQL INJECTION RISK!
                "ORDER BY al.title";

        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement(); // Should use PreparedStatement!
             ResultSet results = statement.executeQuery(query)) {

            while (results.next()) {
                int albumId = results.getInt("album_id");
                int artistId = results.getInt("artist_id");
                String title = results.getString("title");
                int releaseYear = results.getInt("release_year");
                String artistName = results.getString("artist_name");

                albums.add(new Album(albumId, artistId, title, releaseYear, artistName));
            }

        } catch (SQLException e) {
            System.err.println("Error getting albums by genre: " + e.getMessage());
            e.printStackTrace();
        }

        return albums;
    }

    /**
     * Searches for albums by title (partial match)
     * @param searchTerm The album title to search for
     * @return List of matching albums
     *
     */
    public List<Album> searchAlbums(String searchTerm) {
        List<Album> albums = new ArrayList<>();
        String query = "SELECT al.album_id, al.artist_id, al.title, al.release_year, ar.name as artist_name " +
                "FROM albums al " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE al.title LIKE ? " +
                "ORDER BY al.title";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, "%" + searchTerm + "%");

            try (ResultSet results = statement.executeQuery()) {
                while (results.next()) {
                    int albumId = results.getInt("album_id");
                    String artistIdStr = results.getString("artist_id"); // WRONG! Should be getInt
                    int artistId = Integer.parseInt(artistIdStr); // Extra unnecessary step
                    String title = results.getString("title");
                    int releaseYear = results.getInt("release_year");
                    String artistName = results.getString("artist_name");

                    albums.add(new Album(albumId, artistId, title, releaseYear, artistName));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error searching for albums: " + e.getMessage());
            e.printStackTrace();
        }

        return albums;
    }

    public List<ReportResult> getDailyActiveUsersReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    DATE(played_at) as activity_date, " +
                "    COUNT(DISTINCT user_id) as daily_active_users " +
                "FROM album_plays " +
                "WHERE played_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) " +
                "GROUP BY DATE(played_at) " +
                "ORDER BY activity_date DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("activity_date", rs.getDate("activity_date").toLocalDate());
                result.addColumn("daily_active_users", rs.getInt("daily_active_users"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Daily Active Users report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getTopAlbumsThisMonthReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    al.title as album_title, " +
                "    ar.name as artist_name, " +
                "    COUNT(*) as play_count " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "WHERE YEAR(ap.played_at) = YEAR(CURDATE()) " +
                "  AND MONTH(ap.played_at) = MONTH(CURDATE()) " +
                "GROUP BY al.album_id, al.title, ar.name " +
                "ORDER BY play_count DESC " +
                "LIMIT 10";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("album_title", rs.getString("album_title"));
                result.addColumn("artist_name", rs.getString("artist_name"));
                result.addColumn("play_count", rs.getInt("play_count"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Top Albums This Month report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getUserRetentionReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    DATE_FORMAT(u.signup_date, '%Y-%W') as signup_week, " +
                "    COUNT(DISTINCT u.user_id) as total_signups, " +
                "    COUNT(DISTINCT CASE " +
                "        WHEN ap.played_at >= DATE_ADD(u.signup_date, INTERVAL 7 DAY) " +
                "         AND ap.played_at < DATE_ADD(u.signup_date, INTERVAL 14 DAY) " +
                "        THEN u.user_id " +
                "    END) as retained_users, " +
                "    ROUND( " +
                "        COUNT(DISTINCT CASE " +
                "            WHEN ap.played_at >= DATE_ADD(u.signup_date, INTERVAL 7 DAY) " +
                "             AND ap.played_at < DATE_ADD(u.signup_date, INTERVAL 14 DAY) " +
                "            THEN u.user_id " +
                "        END) * 100.0 / COUNT(DISTINCT u.user_id), " +
                "        2 " +
                "    ) as retention_rate_percent " +
                "FROM users u " +
                "LEFT JOIN album_plays ap ON u.user_id = ap.user_id " +
                "WHERE u.signup_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY) " +
                "GROUP BY DATE_FORMAT(u.signup_date, '%Y-%W') " +
                "ORDER BY signup_week DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("signup_week", rs.getString("signup_week"));
                result.addColumn("total_signups", rs.getInt("total_signups"));
                result.addColumn("retained_users", rs.getInt("retained_users"));
                result.addColumn("retention_rate_percent", rs.getDouble("retention_rate_percent"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running User Retention report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getMonthlyActiveByCountryReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    u.country, " +
                "    DATE_FORMAT(ap.played_at, '%Y-%m') as activity_month, " +
                "    COUNT(DISTINCT u.user_id) as monthly_active_users " +
                "FROM album_plays ap " +
                "JOIN users u ON ap.user_id = u.user_id " +
                "WHERE ap.played_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) " +
                "GROUP BY u.country, DATE_FORMAT(ap.played_at, '%Y-%m') " +
                "HAVING COUNT(DISTINCT u.user_id) >= 1 " +
                "ORDER BY activity_month DESC, monthly_active_users DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("country", rs.getString("country"));
                result.addColumn("activity_month", rs.getString("activity_month"));
                result.addColumn("monthly_active_users", rs.getInt("monthly_active_users"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Monthly Active by Country report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getArtistRevenueReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    ar.name as artist_name, " +
                "    ar.primary_genre, " +
                "    COUNT(ap.play_id) as total_plays, " +
                "    SUM(CASE WHEN u.subscription_type = 'premium' THEN 1 ELSE 0 END) as premium_plays, " +
                "    SUM(CASE WHEN u.subscription_type = 'free' THEN 1 ELSE 0 END) as free_plays, " +
                "    ROUND( " +
                "        (SUM(CASE WHEN u.subscription_type = 'premium' THEN 0.004 ELSE 0.001 END)), " +
                "        2 " +
                "    ) as estimated_revenue_usd " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "JOIN users u ON ap.user_id = u.user_id " +
                "GROUP BY ar.artist_id, ar.name, ar.primary_genre " +
                "ORDER BY estimated_revenue_usd DESC " +
                "LIMIT 50";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("artist_name", rs.getString("artist_name"));
                result.addColumn("primary_genre", rs.getString("primary_genre"));
                result.addColumn("total_plays", rs.getInt("total_plays"));
                result.addColumn("premium_plays", rs.getInt("premium_plays"));
                result.addColumn("free_plays", rs.getInt("free_plays"));
                result.addColumn("estimated_revenue_usd", rs.getDouble("estimated_revenue_usd"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Artist Revenue report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getChurnRiskReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    u.user_id, " +
                "    u.username, " +
                "    u.email, " +
                "    u.country, " +
                "    DATEDIFF(CURDATE(), MAX(ap.played_at)) as days_since_last_play, " +
                "    COUNT(ap.play_id) as lifetime_plays, " +
                "    CASE " +
                "        WHEN DATEDIFF(CURDATE(), MAX(ap.played_at)) >= 30 THEN 'High Risk' " +
                "        WHEN DATEDIFF(CURDATE(), MAX(ap.played_at)) >= 21 THEN 'Medium Risk' " +
                "        WHEN DATEDIFF(CURDATE(), MAX(ap.played_at)) >= 14 THEN 'Low Risk' " +
                "    END as churn_risk_level " +
                "FROM users u " +
                "LEFT JOIN album_plays ap ON u.user_id = ap.user_id " +
                "WHERE u.subscription_type = 'premium' " +
                "GROUP BY u.user_id, u.username, u.email, u.country " +
                "HAVING DATEDIFF(CURDATE(), MAX(ap.played_at)) >= 14 " +
                "ORDER BY days_since_last_play DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("user_id", rs.getInt("user_id"));
                result.addColumn("username", rs.getString("username"));
                result.addColumn("email", rs.getString("email"));
                result.addColumn("country", rs.getString("country"));
                result.addColumn("days_since_last_play", rs.getInt("days_since_last_play"));
                result.addColumn("lifetime_plays", rs.getInt("lifetime_plays"));
                result.addColumn("churn_risk_level", rs.getString("churn_risk_level"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Churn Risk report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getListeningBySubscriptionReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    u.subscription_type, " +
                "    COUNT(DISTINCT u.user_id) as total_users, " +
                "    COUNT(ap.play_id) as total_plays, " +
                "    ROUND(COUNT(ap.play_id) / COUNT(DISTINCT u.user_id), 2) as avg_plays_per_user " +
                "FROM users u " +
                "LEFT JOIN album_plays ap ON u.user_id = ap.user_id " +
                "GROUP BY u.subscription_type " +
                "ORDER BY u.subscription_type";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("subscription_type", rs.getString("subscription_type"));
                result.addColumn("total_users", rs.getInt("total_users"));
                result.addColumn("total_plays", rs.getInt("total_plays"));
                result.addColumn("avg_plays_per_user", rs.getDouble("avg_plays_per_user"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Listening by Subscription report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getMostActiveCountriesReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    u.country, " +
                "    COUNT(DISTINCT u.user_id) as total_users, " +
                "    COUNT(ap.play_id) as total_plays, " +
                "    ROUND(COUNT(ap.play_id) / COUNT(DISTINCT u.user_id), 2) as avg_plays_per_user " +
                "FROM users u " +
                "JOIN album_plays ap ON u.user_id = ap.user_id " +
                "GROUP BY u.country " +
                "ORDER BY total_plays DESC " +
                "LIMIT 15";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("country", rs.getString("country"));
                result.addColumn("total_users", rs.getInt("total_users"));
                result.addColumn("total_plays", rs.getInt("total_plays"));
                result.addColumn("avg_plays_per_user", rs.getDouble("avg_plays_per_user"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Most Active Countries report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getGenrePopularityReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    ar.primary_genre as genre, " +
                "    COUNT(DISTINCT al.album_id) as total_albums, " +
                "    COUNT(ap.play_id) as total_plays, " +
                "    COUNT(DISTINCT ar.artist_id) as total_artists " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "GROUP BY ar.primary_genre " +
                "ORDER BY total_plays DESC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("genre", rs.getString("genre"));
                result.addColumn("total_albums", rs.getInt("total_albums"));
                result.addColumn("total_plays", rs.getInt("total_plays"));
                result.addColumn("total_artists", rs.getInt("total_artists"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Genre Popularity report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getUserGrowthReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    DATE_FORMAT(signup_date, '%Y-%m') as signup_month, " +
                "    COUNT(user_id) as new_users, " +
                "    SUM(CASE WHEN subscription_type = 'free' THEN 1 ELSE 0 END) as free_signups, " +
                "    SUM(CASE WHEN subscription_type = 'premium' THEN 1 ELSE 0 END) as premium_signups " +
                "FROM users " +
                "WHERE signup_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) " +
                "GROUP BY DATE_FORMAT(signup_date, '%Y-%m') " +
                "ORDER BY signup_month ASC";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("signup_month", rs.getString("signup_month"));
                result.addColumn("new_users", rs.getInt("new_users"));
                result.addColumn("free_signups", rs.getInt("free_signups"));
                result.addColumn("premium_signups", rs.getInt("premium_signups"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running User Growth report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getCompletionRateReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    CASE " +
                "        WHEN completed = TRUE THEN 'Completed' " +
                "        ELSE 'Incomplete' " +
                "    END as play_status, " +
                "    COUNT(play_id) as total_plays, " +
                "    ROUND(COUNT(play_id) * 100.0 / (SELECT COUNT(*) FROM album_plays), 2) as percentage " +
                "FROM album_plays " +
                "GROUP BY completed " +
                "ORDER BY play_status";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("play_status", rs.getString("play_status"));
                result.addColumn("total_plays", rs.getInt("total_plays"));
                result.addColumn("percentage", rs.getDouble("percentage"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Completion Rate report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<ReportResult> getTopArtistsReport() {
        List<ReportResult> results = new ArrayList<>();
        String query = "SELECT " +
                "    ar.name as artist_name, " +
                "    ar.primary_genre as genre, " +
                "    COUNT(DISTINCT al.album_id) as total_albums_played, " +
                "    COUNT(ap.play_id) as total_plays, " +
                "    COUNT(DISTINCT ap.user_id) as unique_listeners " +
                "FROM album_plays ap " +
                "JOIN albums al ON ap.album_id = al.album_id " +
                "JOIN artists ar ON al.artist_id = ar.artist_id " +
                "GROUP BY ar.artist_id, ar.name, ar.primary_genre " +
                "ORDER BY total_plays DESC " +
                "LIMIT 20";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                ReportResult result = new ReportResult();
                result.addColumn("artist_name", rs.getString("artist_name"));
                result.addColumn("genre", rs.getString("genre"));
                result.addColumn("total_albums_played", rs.getInt("total_albums_played"));
                result.addColumn("total_plays", rs.getInt("total_plays"));
                result.addColumn("unique_listeners", rs.getInt("unique_listeners"));
                results.add(result);
            }

        } catch (SQLException e) {
            System.err.println("Error running Top Artists report: " + e.getMessage());
            e.printStackTrace();
        }

        return results;
    }

    public List<String> getAllGenres() {
        List<String> genres = new ArrayList<>();
        String query = "SELECT DISTINCT primary_genre FROM artists ORDER BY primary_genre";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet results = statement.executeQuery()) {

            while (results.next()) {
                genres.add(results.getString("primary_genre"));
            }

        } catch (SQLException e) {
            System.err.println("Error getting genres: " + e.getMessage());
            e.printStackTrace();
        }

        return genres;
    }
}
package com.mangomusic;

import com.mangomusic.config.DatabaseConfig;
import com.mangomusic.dao.MangoMusicDataManager;
import com.mangomusic.ui.HomeScreen;
import com.mangomusic.ui.ReportsScreen;
import com.mangomusic.ui.SearchScreen;
import com.mangomusic.ui.SpecialReportsScreen;

/**
 * Main entry point for the MangoMusic Database Tool
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Initializing MangoMusic Database Tool...\n");

        try {
            // Initialize data manager
            MangoMusicDataManager dataManager = new MangoMusicDataManager();

            // Initialize screens
            SearchScreen searchScreen = new SearchScreen(dataManager);
            ReportsScreen reportsScreen = new ReportsScreen(dataManager);
            SpecialReportsScreen specialReportsScreen = new SpecialReportsScreen(dataManager);
            HomeScreen homeScreen = new HomeScreen(searchScreen, reportsScreen, specialReportsScreen);

            // Start the application
            homeScreen.display();

            // Clean up
            DatabaseConfig.closeDataSource();

        } catch (Exception e) {
            System.err.println("Fatal error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}